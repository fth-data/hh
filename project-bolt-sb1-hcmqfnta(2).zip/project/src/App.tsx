import { useState } from 'react';
import { Container, Typography, Box, Paper } from '@mui/material';
import { PatientForm } from './components/PatientForm/PatientForm';
import { PatientList } from './components/PatientList/PatientList';
import { Patient } from './types/patient';
import { MESSAGES } from './constants/messages';

function App() {
  const [patients, setPatients] = useState<Patient[]>([]);

  const handleAddPatient = (newPatient: Omit<Patient, 'id'>) => {
    const patient: Patient = {
      ...newPatient,
      id: crypto.randomUUID()
    };
    setPatients([...patients, patient]);
    alert(MESSAGES.PATIENT_ADDED);
  };

  const handleDeletePatient = (id: string) => {
    setPatients(patients.filter(patient => patient.id !== id));
    alert(MESSAGES.PATIENT_REMOVED);
  };

  return (
    <Box sx={{ minHeight: '100vh', backgroundColor: 'background.default', py: 4 }}>
      <Container maxWidth="md">
        <Paper 
          elevation={3} 
          sx={{ 
            p: 4,
            backgroundColor: 'background.paper',
            borderRadius: 2
          }}
        >
          <Typography 
            variant="h4" 
            component="h1" 
            gutterBottom 
            align="center"
            sx={{ 
              mb: 4, 
              color: 'primary.main',
              fontWeight: 600
            }}
          >
            Sistem E-Health
          </Typography>
          
          <Box sx={{ mb: 4 }}>
            <Typography 
              variant="h6" 
              gutterBottom
              sx={{ color: 'text.primary' }}
            >
              Tambah Pasien Baru
            </Typography>
            <PatientForm onSubmit={handleAddPatient} />
          </Box>
          
          <PatientList patients={patients} onDelete={handleDeletePatient} />
        </Paper>
      </Container>
    </Box>
  );
}

export default App;