import React from 'react';
import { List, ListItem, ListItemText, IconButton, Paper, Typography, Divider } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import { Patient } from '../../types/patient';
import { MESSAGES } from '../../constants/messages';

interface PatientListProps {
  patients: Patient[];
  onDelete: (id: string) => void;
}

export const PatientList: React.FC<PatientListProps> = ({ patients, onDelete }) => {
  const handleDelete = (id: string) => {
    if (window.confirm(MESSAGES.CONFIRM_DELETE)) {
      onDelete(id);
    }
  };

  if (patients.length === 0) {
    return (
      <Paper 
        elevation={2} 
        sx={{ 
          mt: 2, 
          p: 3, 
          textAlign: 'center',
          backgroundColor: 'background.paper'
        }}
      >
        <Typography variant="body1" color="text.secondary">
          Belum ada data pasien
        </Typography>
      </Paper>
    );
  }

  return (
    <Paper 
      elevation={2} 
      sx={{ 
        mt: 2, 
        p: 2,
        backgroundColor: 'background.paper'
      }}
    >
      <Typography 
        variant="h6" 
        gutterBottom
        sx={{ color: 'text.primary', mb: 2 }}
      >
        Daftar Pasien
      </Typography>
      <List>
        {patients.map((patient, index) => (
          <React.Fragment key={patient.id}>
            <ListItem
              secondaryAction={
                <IconButton 
                  edge="end" 
                  onClick={() => handleDelete(patient.id)}
                  color="error"
                >
                  <DeleteIcon />
                </IconButton>
              }
            >
              <ListItemText
                primary={
                  <Typography variant="subtitle1" color="text.primary">
                    {patient.name}
                  </Typography>
                }
                secondary={
                  <Typography variant="body2" color="text.secondary">
                    Umur: {patient.age} | Jenis Kelamin: {
                      patient.gender === 'Male' ? 'Laki-laki' : 
                      patient.gender === 'Female' ? 'Perempuan' : 
                      'Lainnya'
                    } | Kondisi: {patient.condition}
                  </Typography>
                }
              />
            </ListItem>
            {index < patients.length - 1 && <Divider />}
          </React.Fragment>
        ))}
      </List>
    </Paper>
  );
};