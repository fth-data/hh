import React, { useState } from 'react';
import { TextField, Button, Select, MenuItem, FormControl, InputLabel, Box } from '@mui/material';
import { Gender, Patient } from '../../types/patient';
import { MESSAGES } from '../../constants/messages';

interface PatientFormProps {
  onSubmit: (patient: Omit<Patient, 'id'>) => void;
}

export const PatientForm: React.FC<PatientFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: Gender.Male,
    condition: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.age || !formData.condition) {
      alert(MESSAGES.REQUIRED_FIELDS);
      return;
    }

    onSubmit({
      name: formData.name,
      age: parseInt(formData.age),
      gender: formData.gender,
      condition: formData.condition
    });

    setFormData({
      name: '',
      age: '',
      gender: Gender.Male,
      condition: ''
    });
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <TextField
        label="Nama Pasien"
        value={formData.name}
        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
        required
        fullWidth
      />
      <TextField
        label="Umur"
        type="number"
        value={formData.age}
        onChange={(e) => setFormData({ ...formData, age: e.target.value })}
        required
        fullWidth
      />
      <FormControl fullWidth>
        <InputLabel>Jenis Kelamin</InputLabel>
        <Select
          value={formData.gender}
          onChange={(e) => setFormData({ ...formData, gender: e.target.value as Gender })}
          label="Jenis Kelamin"
        >
          <MenuItem value={Gender.Male}>Laki-laki</MenuItem>
          <MenuItem value={Gender.Female}>Perempuan</MenuItem>
          <MenuItem value={Gender.Other}>Lainnya</MenuItem>
        </Select>
      </FormControl>
      <TextField
        label="Kondisi Medis"
        value={formData.condition}
        onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
        required
        multiline
        rows={3}
        fullWidth
      />
      <Button 
        type="submit" 
        variant="contained" 
        color="primary"
        size="large"
        sx={{ mt: 2 }}
      >
        Tambah Pasien
      </Button>
    </Box>
  );
};