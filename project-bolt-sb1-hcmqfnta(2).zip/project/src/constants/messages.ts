export const MESSAGES = {
  PATIENT_ADDED: 'Pasien berhasil ditambahkan',
  PATIENT_REMOVED: 'Pasien berhasil dihapus',
  CONFIRM_DELETE: 'Apakah Anda yakin ingin menghapus pasien ini?',
  REQUIRED_FIELDS: 'Mohon isi semua field yang diperlukan'
} as const;